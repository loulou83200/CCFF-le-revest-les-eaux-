// app.js - comportement dynamique côté client

// données par défaut (exemples)
const DATA = {
  missions: [
    {id:1, title:'Patrouilles préventives', type:'prevention', desc:'Surveillance des massifs et information des usagers.'},
    {id:2, title:'Intervention initiale', type:'intervention', desc:'Mise en sécurité et relais aux secours.'},
    {id:3, title:'Formation radio', type:'formation', desc:'Ateliers réguliers pour bénévoles.'},
    {id:4, title:'Sensibilisation scolaire', type:'prevention', desc:'Interventions auprès des écoles locales.'},
    {id:5, title:'Vérification points d\'eau', type:'surveillance', desc:'Contrôles des points d\'eau accessibles.'}
  ],
  team: [
    {id:1, name:'Jean Dupont', role:'Responsable', bio:'Coordinateur local, formateur.'},
    {id:2, name:'Sophie Martin', role:'Formateur', bio:'Spécialiste sécurité et prévention.'},
    {id:3, name:'Ali Ben', role:'Patrouilleur', bio:'Cartographie et logistique.'}
  ],
  demoEvents: [
    {id:'demo1', title:'Réunion mensuelle', date: new Date().toISOString().slice(0,10), place:'Salle des fêtes', note:'19h - Tous bénévoles'},
    {id:'demo2', title:'Exercice interservices', date: new Date(Date.now()+7*24*3600*1000).toISOString().slice(0,10), place:'Terrain d\'entraînement', note:'Matinée'}
  ]
}

// utilitaires
function qs(sel){ return document.querySelector(sel) }
function qsa(sel){ return Array.from(document.querySelectorAll(sel)) }
function showToast(text, timeout=2200){
  const t = qs('#toast'); t.textContent = text; t.classList.remove('hidden');
  setTimeout(()=> t.classList.add('hidden'), timeout);
}

// navigation mobile
const navToggle = qs('#navToggle'), navList = qs('#navList');
navToggle && navToggle.addEventListener('click', ()=>{
  const expanded = navToggle.getAttribute('aria-expanded') === 'true';
  navToggle.setAttribute('aria-expanded', String(!expanded));
  navList.style.display = expanded ? 'none' : 'flex';
})

// Missions render
function renderMissions(filter='all'){
  const list = qs('#missionsList');
  list.innerHTML = '';
  const items = DATA.missions.filter(m=> filter==='all' ? true : m.type===filter);
  if(items.length===0){ list.innerHTML = '<div class="muted">Aucune mission trouvée.</div>'; return; }
  items.forEach(m=>{
    const li = document.createElement('li'); li.className='item';
    li.innerHTML = `<div><strong>${m.title}</strong><div class="muted small">${m.type}</div><div class="muted">${m.desc}</div></div>`;
    list.appendChild(li);
  });
}

// Team render
function renderTeam(){
  const el = qs('#teamList'); el.innerHTML='';
  DATA.team.forEach(p=>{
    const d = document.createElement('div'); d.className='team-card';
    d.innerHTML = `<strong>${p.name}</strong><div class="muted small">${p.role}</div><p class="muted">${p.bio}</p>`;
    el.appendChild(d);
  });
}

// Events management (stored in localStorage)
const EVENTS_KEY = 'ccff_revest_events';
function loadEvents(){ try{ return JSON.parse(localStorage.getItem(EVENTS_KEY) || '[]') }catch(e){ return [] } }
function saveEvents(evts){ localStorage.setItem(EVENTS_KEY, JSON.stringify(evts)) }
function renderCalendar(){
  const container = qs('#calendar'); container.innerHTML='';
  const evts = loadEvents();
  if(evts.length===0){ container.innerHTML = '<div class="muted">Aucun événement enregistré.</div>'; qs('#nextEvent').textContent='Aucun événement à venir'; return; }
  evts.sort((a,b)=> new Date(a.date) - new Date(b.date));
  evts.forEach(e=>{
    const div = document.createElement('div'); div.className='item';
    div.innerHTML = `<div><strong>${e.title}</strong><div class="muted small">${new Date(e.date).toLocaleDateString()} · ${e.place || ''}</div><div class="muted">${e.note || ''}</div></div><div><button class="btn" data-id="${e.id}">Supprimer</button></div>`;
    container.appendChild(div);
  });
  const next = evts.find(e=> new Date(e.date) >= new Date());
  qs('#nextEvent').textContent = next ? `${next.title} — ${new Date(next.date).toLocaleDateString()}` : 'Aucun événement à venir';
}

// add / remove events
qs('#eventForm').addEventListener('submit', (ev)=>{
  ev.preventDefault();
  const title = qs('#evt_title').value.trim();
  const date = qs('#evt_date').value;
  const place = qs('#evt_place').value.trim();
  const note = qs('#evt_note').value.trim();
  if(!title || !date){ showToast('Titre et date requis'); return; }
  const evts = loadEvents(); evts.push({id:'evt_'+Date.now(), title, date, place, note}); saveEvents(evts); renderCalendar(); ev.target.reset(); showToast('Événement ajouté');
});

qs('#calendar').addEventListener('click', (e)=>{
  if(e.target.tagName === 'BUTTON' && e.target.dataset.id){ const id = e.target.dataset.id; const evts = loadEvents().filter(x=> x.id !== id); saveEvents(evts); renderCalendar(); showToast('Événement supprimé'); }
});

qs('#clearEvents').addEventListener('click', ()=>{ if(confirm('Supprimer tous les événements ?')){ saveEvents([]); renderCalendar(); showToast('Événements effacés'); } });

qs('#addDemoEvent').addEventListener('click', ()=>{ const evts = loadEvents(); evts.push(...DATA.demoEvents.map(d=> Object.assign({}, d, { id: d.id+'_'+Date.now() }))); saveEvents(evts); renderCalendar(); showToast('Événements de démonstration ajoutés'); });

qs('#exportEvents').addEventListener('click', ()=>{
  const data = JSON.stringify(loadEvents(), null, 2);
  const blob = new Blob([data], {type: 'application/json'});
  const url = URL.createObjectURL(blob);
  const a = document.createElement('a'); a.href = url; a.download = 'ccff_events.json'; document.body.appendChild(a); a.click(); a.remove();
  URL.revokeObjectURL(url);
  showToast('Exporté en JSON');
});

// Contact & signup forms (simulate storage)
qs('#signupForm').addEventListener('submit', (e)=>{
  e.preventDefault();
  const payload = {id:'app_'+Date.now(), name:qs('#name').value, email:qs('#email').value, phone:qs('#phone').value, availability:qs('#availability').value, motivation:qs('#motivation').value};
  const apps = JSON.parse(localStorage.getItem('ccff_revest_apps') || '[]'); apps.push(payload); localStorage.setItem('ccff_revest_apps', JSON.stringify(apps));
  qs('#signupResult').textContent = 'Merci — votre candidature a été enregistrée (simulation).';
  e.target.reset();
  showToast('Candidature enregistrée');
});

qs('#contactForm').addEventListener('submit', (e)=>{
  e.preventDefault();
  const msg = {id:'msg_'+Date.now(), name:qs('#c_name').value, email:qs('#c_email').value, message:qs('#c_message').value};
  const msgs = JSON.parse(localStorage.getItem('ccff_revest_msgs') || '[]'); msgs.push(msg); localStorage.setItem('ccff_revest_msgs', JSON.stringify(msgs));
  showToast('Message envoyé (simulation)');
  e.target.reset();
});

// Filter missions select
qs('#filter').addEventListener('change', (e)=> renderMissions(e.target.value));

// open events section
qs('#openEvents').addEventListener('click', ()=> { location.hash = '#evenements'; document.getElementById('evenements').scrollIntoView({behavior:'smooth'}); });

// init
renderMissions();
renderTeam();
if(loadEvents().length === 0){
  saveEvents(DATA.demoEvents);
}
renderCalendar();

