# CCFF Le Revest‑les‑Eaux - Site (démonstration)

Ce dépôt contient un site web simple (HTML + CSS + JS) pour le **CCFF Le Revest‑les‑Eaux**.
Le but : fournir une base prête à déployer (GitHub Pages, Netlify, Vercel...) et facilement éditable.

## Structure
```
/index.html
/css/style.css
/js/app.js
/assets/    # pour images (vide)
README.md
```

## Fonctionnalités
- Pages/sections : À propos, Missions, Événements, Équipe, Inscription, Contact.
- Événements enregistrés dans `localStorage` (simulation côté client) : ajout, suppression, export JSON.
- Formulaires (inscription & contact) : stockage simulé dans `localStorage`.
- Responsive, accessible et sans dépendances externes.

## Personnalisation recommandée
- Remplace les textes, coordonnées et images par les informations officielles du CCFF.
- Pour rendre le site «vraiment dynamique», connecte un backend (Node, PHP, Firebase, etc.) pour stocker messages et candidatures.
- Mets à jour l'iframe OpenStreetMap avec les coordonnées exactes de ton point de rassemblement.

## Déploiement (GitHub Pages)
1. Crée un nouveau dépôt sur GitHub (par ex. `ccff-le-revest`).
2. Ajoute les fichiers et pousse sur la branche `main` (ou `gh-pages` si tu préfères).
3. Dans les *Settings* du dépôt → *Pages*, choisis la branche `main` et le dossier `/ (root)`. Enregistre.
4. Attend ~1 à 2 minutes, le site sera disponible à `https://<ton-utilisateur>.github.io/<nom-du-depot>/`.

---

Code fourni à titre d'exemple — vérifier et remplacer les données avant publication officielle.
